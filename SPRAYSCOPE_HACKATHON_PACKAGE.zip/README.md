# SprayScope

CyberNova's browser-based VPN authentication threat detection prototype.

## Run locally

Requires Node.js 20 or newer (no third-party packages or build step):

```powershell
cd C:\Users\manish\OneDrive\Desktop\SPRAYSCOPE
npm start
```

Open <http://localhost:4173>. The Node server serves the frontend and the hackathon API. Stop it with Ctrl+C. `GET /api/health` checks the backend; `GET /api/events` reads portal telemetry and `POST /api/events` records it. Event data is persisted in `backend/storage/events.json` and shared with other clients polling the same server.

## Microsoft sign-in setup

The Microsoft button uses MSAL Browser with the Microsoft identity platform redirect flow. Register SprayScope as a Single-page application in Microsoft Entra ID, add `http://localhost:4173/` as its SPA redirect URI, then put the Application (client) ID in `frontend/src/authConfig.js`. The default authority is `common` (work/school and personal Microsoft accounts); for organization-only sign-in, set the authority to that tenant's ID. No client secret belongs in this browser app. Until the client ID is configured, the Microsoft button explains the required setup and does not create a fake signed-in session.

## Workflow

Create an account from the Sign Up option, then sign in with the same email and password. For this static prototype, account records and salted PBKDF2 password hashes are stored in the current browser; this is not a production identity store. Load the local demonstration sample or upload CSV/JSON authentication events, review the column mapping, then run detection. Supported detections are brute force (10 failed events/user/5 minutes), password spray (10 users/source/10 minutes and no more than 5 events/user on average), impossible travel (known country codes and centroid-based travel estimates), credential stuffing, abnormal login bursts, and account enumeration when rejection details identify unknown usernames. These are transparent prototype heuristics, not a trained production model.

After sign-in, the Overview starts with an unlabeled analyst demo stream designed to exercise three distinct scenarios: a password spray, a brute-force run, and a US-to-UK impossible-travel sequence. Additional benign events are simulated locally while the session remains open. The stream and its changing metrics are illustrative; confidence is a rule-match score, not measured model accuracy. Loading or uploading another dataset replaces the stream.

The **User VPN Portal** is a local training page for generating sign-in telemetry. Open `http://localhost:4173/?portal=1` directly, or use the link on the analyst sign-in page. A single form submission records one attempted login; the scenario buttons generate brute-force, password-spray, and impossible-travel patterns that the same detection rules analyze and show on Overview. The portal sends events to the backend; the analyst dashboard polls for shared events. Browser local storage is a fallback when the API is unavailable. Password values are never written to storage or sent to the API, and the portal does not authenticate a real account or connect to a VPN. Source IPs, outcomes, and device details are simulated.

This backend is a hackathon demo service, not production identity infrastructure. It has no analyst account API, VPN control plane, TLS termination, or production-grade access controls. Deploy behind an HTTPS platform and add real identity/VPN integrations before handling real users or authentication traffic.

CSV fields are mapped to timestamp, username, source_ip, result and optional country, user_agent, and device. Success/failure is inferred from common result words. Unrecognized values remain unknown. Files are parsed in the browser and are not uploaded to a server.

Use Settings to generate explicitly labelled synthetic logs and evaluate event-level precision, recall, confusion counts, and alert-to-TP ratio. Unlabelled demo and uploaded datasets show metrics as unavailable. The Dataset page has one-click attack-specific labelled fixtures and downloads: `dataset/brute-force-only.csv`, `dataset/password-spray-only.csv`, and `dataset/impossible-travel-only.csv`. `dataset/demo-authentication.csv` remains the mixed sample. Exports include event CSV, incident JSON, and a text report. KQL and alert buttons create local previews only.

## LogHub source

LogHub is referenced at <https://github.com/logpai/loghub>. The “Load Demo Dataset” button loads a small illustrative sample bundled with this project; it does not download LogHub or claim to contain its corpus. Upload the relevant LogHub-derived authentication logs (or another auth log export) for analysis.

## LANL model benchmark

`dataset/scripts/train_lanl.py` trains a scikit-learn logistic-regression baseline against LANL `auth.txt.gz`, using exact event matches from `redteam.txt.gz` as known attack labels. It uses chronological train/validation/test splits and weighted metrics for randomly sampled negative events. Install dependencies with `python -m pip install -r dataset/requirements-ml.txt`, place both source files in `dataset/lanl/`, then run `python dataset/scripts/train_lanl.py`. The model and measured holdout report are written under `dataset/models/lanl/`. This is an offline research benchmark: LANL identities are anonymized and the auth logs do not contain IP addresses or countries, so its metrics do not validate the website’s VPN or impossible-travel detections and the model is not connected to the live dashboard.

## Source layout

`frontend/` contains the SPA, styles, and browser-side modules; `backend/server.js` contains the Node API and static-file server; `dataset/` contains CSV fixtures and optional offline ML scripts/data. Root `package.json` keeps `npm start` as the one-command launcher.

## Hackathon team handoff

See [TEAM_HANDOFF.md](TEAM_HANDOFF.md) for the five-person frontend/backend/dataset work split, file ownership, API notes, dataset provenance, and the local run workflow. `SPRAYSCOPE_HACKATHON_PACKAGE.zip` is a clean source-and-demo-data handoff; it excludes the partial LANL download and generated portal telemetry.
